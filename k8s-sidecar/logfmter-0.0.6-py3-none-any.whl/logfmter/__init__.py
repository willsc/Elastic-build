# flake8: noqa

from logfmter.formatter import Logfmter

__version__ = "0.0.6"
