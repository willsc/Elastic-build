# Default

This example deploy Logstash 7.17.3 using [default values][].


## Usage

* Deploy Logstash chart with the default values: `make install`


## Testing

You can also run [goss integration tests][] using `make test`


[goss integration tests]: https://github.com/elastic/helm-charts/tree/7.17/logstash/examples/default/test/goss.yaml
[default values]: https://github.com/elastic/helm-charts/tree/7.17/logstash/values.yaml
